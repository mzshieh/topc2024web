x, y = input().split()
try:
    print(int(x)-int(y))
except:
    print('NaN')

n = int(input())
print(n / 2 / (n-1))

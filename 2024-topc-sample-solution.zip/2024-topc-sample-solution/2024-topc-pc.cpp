#include <bits/stdc++.h>
using namespace std;

using ll = long long;

struct BIT {
  int n;
  vector<int> d;

  void init(int _n) {
    n = _n;
    d.resize(n + 1);
    fill(d.begin(), d.end(), 0);
  }

  void add(int x, int dd) {
    for (int i = x; i <= n; i += (i & (-i)))
      d[i] += dd;
  }

  int query(int x) {
    if (x <= 0)
      return 0;
    int ret = 0;
    for (int i = x; i > 0; i -= (i & (-i)))
      ret += d[i];
    return ret;
  }
} bit;

ll count_inversions(int n, vector<int> &p) {
  ll ret = 0;
  bit.init(n);
  for (int i = n; i >= 1; i--) {
    ret += bit.query(p[i]);
    bit.add(p[i], 1);
  }
  return ret;
}

int main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  int n;
  cin >> n;
  vector<int> p(n + 1), invp(n + 1);
  vector<int> a(n + 1), b(n + 1);
  for (int i = 1; i <= n; i++)
    cin >> a[i];
  for (int i = 1; i <= n; i++)
    cin >> b[i];
  for (int i = 1; i <= n; i++)
    p[a[i]] = b[i], invp[b[i]] = a[i];

  // check if parity of two permutations are the same
  ll current_inversions = count_inversions(n, p);
  if (current_inversions & 1) {
    cout << "No\n";
    return 0;
  }

  // special case
  if (current_inversions == 0) {
    cout << "Yes\n";
    for (int i = 1; i <= n; i++)
      cout << a[i] << " \n"[i == n];
    for (int i = 1; i <= n; i++)
      cout << b[i] << " \n"[i == n];
    return 0;
  }

  ll which_i = 0, which_prev = 0;
  ll target = current_inversions / 2;
  bit.init(n);
  for (int i = 1; i <= n; i++) {
    int idx = invp[i];
    int cur = (idx - 1) - bit.query(idx - 1);
    bit.add(invp[i], 1);

    if (target <= cur) {
      which_i = i;
      for (int j = idx - 1; j >= 1; j--) {
        if (p[j] > i)
          target--;
        if (target == 0) {
          which_prev = j;
          break;
        }
      }
      break;
    } else {
      target -= cur;
    }
  }

  vector<int> ansa(n + 1), ansb(n + 1);
  for (int i = 1; i <= which_i - 1; i++)
    ansb[i] = i, ansa[i] = invp[i];
  int ans_idx = which_i;
  for (int i = 1; i <= n; i++) {
    if (p[i] <= which_i)
      continue;
    if (i == which_prev) {
      ansa[ans_idx] = invp[which_i];
      ansb[ans_idx] = which_i;
      ansa[ans_idx + 1] = i;
      ansb[ans_idx + 1] = p[i];
      ans_idx += 2;
    } else {
      ansa[ans_idx] = i;
      ansb[ans_idx] = p[i];
      ans_idx++;
    }
  }

  cout << "Yes\n";
  for (int i = 1; i <= n; i++)
    cout << ansa[i] << " \n"[i == n];
  for (int i = 1; i <= n; i++)
    cout << ansb[i] << " \n"[i == n];
}

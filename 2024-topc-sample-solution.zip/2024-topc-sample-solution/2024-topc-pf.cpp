#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
constexpr int MAXN = 1e6 + 7;
constexpr int INF = 2e9;
constexpr ll INFF = 1e18;
#define mkp make_pair
#define F first
#define S second
#define pb emplace_back
#define sz(v) ((int)(v).size())
#define all(v) (v).begin(), (v).end()

ll ppow(ll x, ll y, ll MOD) {
  ll ret = 1;
  while (y) {
    if (y & 1)
      ret = (__int128)ret * x % MOD;
    x = (__int128)x * x % MOD;
    y >>= 1;
  }
  return ret;
}

struct matrix {
  vector<vector<ll>> A;

  matrix() {
    A.resize(2);
    A[0].resize(2);
    A[1].resize(2);
  }

  matrix operator*(const matrix &rhs) const {
    matrix ret;
    for (int i = 0; i < 2; i++)
      for (int j = 0; j < 2; j++)
        for (int k = 0; k < 2; k++)
          ret.A[i][j] =
              (ret.A[i][j] + (__int128)A[i][k] * rhs.A[k][j]) % 10000000000LL;
    return ret;
  }
};

ll get_fib(ll x) {
  matrix I, M;
  I.A[0][0] = I.A[1][1] = 1;
  M.A[0][1] = M.A[1][0] = M.A[1][1] = 1;
  while (x) {
    if (x & 1)
      I = I * M;
    M = M * M;
    x >>= 1;
  }
  return I.A[0][1];
}

int32_t main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  int t;
  cin >> t;
  while (t--) {
    ll n;
    cin >> n;

    // p = 15000000000
    // phi(p) = 4000000000
    // phi(phi(p)) = 1600000000
    n = ppow(7, n, 1600000000LL);
    n = ppow(7, n, 4000000000LL);
    n = ppow(7, n, 15000000000LL);

    cout << setw(10) << setfill('0') << get_fib(n) << '\n';
  }
}

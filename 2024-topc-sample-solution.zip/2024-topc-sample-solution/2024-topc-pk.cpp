#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
constexpr int MAXN = 1e6 + 7;
constexpr int INF = 2e9;
constexpr ll INFF = 1e18;
constexpr ll MOD = 998244353;
#define mkp make_pair
#define F first
#define S second
#define pb emplace_back
#define sz(v) ((int)(v).size())
#define all(v) (v).begin(), (v).end()

int32_t main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  int n, m;
  cin >> n >> m;
  vector<vector<int>> G(n);
  vector<int> indeg(n);
  for (int i = 1; i <= m; i++) {
    int a, b;
    cin >> a >> b;
    a--, b--;
    G[a].pb(b);
    indeg[b]++;
  }

  vector<int> ans;
  priority_queue<int, vector<int>, greater<int>> pq;
  for (int i = 0; i < n; i++)
    if (indeg[i] == 0)
      pq.push(i);
  while (!pq.empty()) {
    int now = pq.top();
    pq.pop();
    ans.pb(now);
    for (int i : G[now]) {
      indeg[i]--;
      if (indeg[i] == 0)
        pq.push(i);
    }
  }
  if (sz(ans) != n)
    cout << "IMPOSSIBLE\n";
  else {
    for (int i : ans)
      cout << i+1 << ' ';
    cout << '\n';
  }
}

#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
constexpr int MAXN = 1e6 + 7;
constexpr int INF = 2e9;
constexpr ll INFF = 1e18;
constexpr ll MOD = 1000000007;
#define mkp make_pair
#define F first
#define S second
#define pb emplace_back
#define sz(v) ((int)(v).size())
#define all(v) (v).begin(), (v).end()

ll ppow(ll x, ll y = MOD - 2) {
  if (y == 0)
    return 1LL;
  ll ret = 1;
  while (y) {
    if (y & 1)
      ret = ret * x % MOD;
    x = x * 1LL * x % MOD;
    y >>= 1;
  }
  return ret;
}

int main() {
  int n, m, d[3];
  cin >> n >> m >> d[0] >> d[1] >> d[2];
  vector<string> a(n);
  for (auto &s : a)
    cin >> s;

  vector<ll> invpow(10);
  invpow[0] = 1;
  for (int i = 1; i < 10; i++)
    invpow[i] = invpow[i - 1] * ppow(2) % MOD;

  auto get = [&](int x, int y) {
    if (x < 0 || x >= n || y < 0 || y >= m)
      return '.';
    else
      return a[x][y];
  };

  auto cal = [&](int x, int y) {
    ll ret = 0;
    vector<int> cnt_V(3), cnt_q(3);
    vector<int> dx = {0, 1, -1, 0, 0, 1, 1, -1, -1};
    vector<int> dy = {0, 0, 0, 1, -1, 1, -1, 1, -1};
    vector<int> idx = {0, 1, 1, 1, 1, 2, 2, 2, 2};

    for (int i = 0; i < 9; i++) {
      auto c = get(x + dx[i], y + dy[i]);
      if (c == 'V')
        cnt_V[idx[i]]++;
      else if (c == '?')
        cnt_q[idx[i]]++;
    }
    int acc_q = 0;
    for (int i = 0; i < 3; i++) {
      if (cnt_V[i]) {
        ret += invpow[acc_q] * d[i];
        break;
      } else {
        ret += (invpow[acc_q] * (MOD + 1 - invpow[cnt_q[i]]) % MOD) * d[i];
        acc_q += cnt_q[i];
      }
    }
    return ret % MOD;
  };

  ll ans = 0;
  for (int i = 0; i < n; i++)
    for (int j = 0; j < m; j++)
      ans = (ans + cal(i, j)) % MOD;
  cout << ans << '\n';
}

#include <bits/stdc++.h>
using namespace std;

using ll = long long;
constexpr int INF = 1000000001;
constexpr ll MOD = 1000000007;

ll ppow(ll x, ll y) {
  ll ret = 1;
  while (y) {
    if (y & 1)
      ret = ret * x % MOD;
    x = x * x % MOD;
    y >>= 1;
  }
  return ret;
}

struct matrix {
  int n;
  ll x, k;
  vector<vector<int>> A;
  vector<vector<ll>> hash;

  matrix(int _n, ll _x, ll _k) {
    n = _n;
    x = _x;
    k = _k;
    A.resize(n);
    hash.resize(n);
    for (int i = 0; i < n; i++) {
      A[i].resize(n, -1);
      hash[i].resize(n, -1);
    }
  }

  matrix operator*(const matrix &rhs) const {
    matrix ret(n, x, k + rhs.k);
    vector<pair<int, int>> values;
    vector<vector<pair<int, int>>> minimum_pair(
        n, vector<pair<int, int>>(n, make_pair(INF, INF)));
    vector<vector<ll>> minimum_hash(n, vector<ll>(n, -1LL));
    ll pow_of_right = ppow(x, rhs.k);

    for (int i = 0; i < n; i++)
      for (int j = 0; j < n; j++) {
        for (int k = 0; k < n; k++) {
          if (A[i][k] != -1 && rhs.A[k][j] != -1 &&
              make_pair(A[i][k], rhs.A[k][j]) < minimum_pair[i][j]) {
            minimum_pair[i][j] =
                min(minimum_pair[i][j], {A[i][k], rhs.A[k][j]});
            minimum_hash[i][j] =
                (hash[i][k] * pow_of_right + rhs.hash[k][j]) % MOD;
          }
        }
        if (minimum_pair[i][j] != make_pair(INF, INF))
          values.push_back(minimum_pair[i][j]);
      }

    sort(values.begin(), values.end());
    values.resize(unique(values.begin(), values.end()) - values.begin());

    for (int i = 0; i < n; i++)
      for (int j = 0; j < n; j++) {
        if (minimum_pair[i][j] != make_pair(INF, INF)) {
          ret.A[i][j] =
              lower_bound(values.begin(), values.end(), minimum_pair[i][j]) -
              values.begin();
          ret.hash[i][j] = minimum_hash[i][j];
        }
      }
    return ret;
  }
};

int main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  int n, m, s, t, x, k;
  cin >> n >> m >> s >> t >> x >> k;

  matrix mat(n, x, 1);
  for (int i = 0; i < m; i++) {
    int u, v, c;
    cin >> u >> v >> c;
    u--, v--;
    mat.A[u][v] = c;
    mat.hash[u][v] = c;
  }

  matrix ans(n, x, 1);
  bool is_assigned = false;
  while (k) {
    if (k & 1) {
      if (is_assigned)
        ans = ans * mat;
      else
        ans = mat, is_assigned = true;
    }
    mat = mat * mat;
    k >>= 1;
  }
  cout << (ans.A[s - 1][t - 1] == -1 ? -1 : ans.hash[s - 1][t - 1]) << '\n';
}

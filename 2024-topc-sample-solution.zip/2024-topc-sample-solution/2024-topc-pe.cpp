#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
constexpr int MAXN = 1e6 + 7;
constexpr int INF = 2e9;
constexpr ll INFF = 1e18;
constexpr ll MOD = 998244353;
#define mkp make_pair
#define F first
#define S second
#define pb emplace_back
#define sz(v) ((int)(v).size())
#define all(v) (v).begin(), (v).end()

int32_t main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  int n, m, d, x;
  cin >> n >> m >> d >> x;
  vector<ll> l(n + 2), r(n + 2);
  vector<ll> nl(n + 2), nr(n + 2);
  ll len = 0;
  for (int i = 1; i <= n; i++)
    cin >> l[i] >> r[i], len += (r[i] - l[i] + 1);
  // assert(len + ll(d) * (n) + x != m);

  nl[0] = 0;
  nl[1] = (r[1] - l[1] + 1);
  for (int i = 2; i <= n; i++)
    nl[i] = nl[i - 1] + d + (r[i] - l[i] + 1);
  nr[n + 1] = m + 1;
  nr[n] = m + 1 - (r[n] - l[n] + 1);
  for (int i = n - 1; i >= 1; i--) {
    nr[i] = nr[i + 1] - d - (r[i] - l[i] + 1);
  }

  auto f = [&](ll p, int i) {
    ll ret = 0;

    ll cur = p;
    for (int j = i; j >= 1; j--) {
      ret += max(0LL, l[j] - (cur - d - (r[j] - l[j] + 1)));
      cur = min(l[j], (cur - d - (r[j] - l[j] + 1)));
    }

    cur = p + x - 1;
    for (int j = i + 1; j <= n; j++) {
      ret += max(0LL, (cur + d + (r[j] - l[j] + 1)) - r[j]);
      cur = max(r[j], (cur + d + (r[j] - l[j] + 1)));
    }
    return ret;
  };

  ll ans = INFF;
  for (int i = 0; i <= n; i++) {
    ll L = (i == 0 ? 1 : nl[i] + d + 1);
    ll R = (i == n ? m - x + 1 : nr[i + 1] - d - x);
    // cout << L << ' ' << R << '\n';
    if (L > R)
      continue;
    while (L != R) {
      ll M = (L + R) >> 1;
      ll val1 = f(M, i), val2 = f(M + 1, i);
      if (val1 == val2) {
        ans = min(ans, val1);
        break;
      } else if (val1 > val2) {
        L = M + 1;
      } else {
        R = M;
      }
    }
    ans = min(ans, f(L, i));
  }
  cout << (ans == INFF ? -1 : ans) << '\n';
}

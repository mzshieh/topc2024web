n = int(input())
a = list(map(int, input().split()))
pre = [0] * (n + 2)
abspre = [0] * (n + 2)
abssuf = [0] * (n + 2)
for i in range(1, n + 1):
    pre[i] = pre[i - 1] + a[i - 1]
    abspre[i] = abspre[i - 1] + abs(a[i - 1])
for i in range(n, 0, -1):
    abssuf[i] = abssuf[i + 1] + abs(a[i - 1])

mn_pre = 0
ans = abspre[n]
for i in range(1, n + 1):
    ans = max(ans, 2 * pre[i] - mn_pre + abssuf[i + 1])
    mn_pre = min(mn_pre, -abspre[i] + 2 * pre[i])
print(ans)

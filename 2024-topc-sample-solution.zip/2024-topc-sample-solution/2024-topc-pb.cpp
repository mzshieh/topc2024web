#include <iostream>
#include <vector>
using namespace std;

using ll = long long;

int main() {
  int n;
  cin >> n;
  vector<int> a(n + 1);
  vector<ll> abspre(n + 2), abssuf(n + 2), pre(n + 2);

  for (int i = 1; i <= n; i++)
    cin >> a[i];
  for (int i = 1; i <= n; i++) {
    abspre[i] = abspre[i - 1] + abs(a[i]);
    pre[i] = pre[i - 1] + a[i];
  }
  for (int i = n; i >= 1; i--)
    abssuf[i] = abssuf[i + 1] + abs(a[i]);

  ll mn_pre = 0;
  ll ans = abspre[n];
  for (int i = 1; i <= n; i++) {
    ans = max(ans, 2 * pre[i] - mn_pre + abssuf[i + 1]);
    mn_pre = min(mn_pre, -abspre[i] + 2 * pre[i]);
  }
  cout << ans << '\n';
}

def matrix_multiply(A, B, mod=10000000000):
    return [
        [(A[0][0] * B[0][0] + A[0][1] * B[1][0]) % mod, (A[0][0] * B[0][1] + A[0][1] * B[1][1]) % mod],
        [(A[1][0] * B[0][0] + A[1][1] * B[1][0]) % mod, (A[1][0] * B[0][1] + A[1][1] * B[1][1]) % mod]
    ]

def matrix_power(matrix, n, mod=10000000000):
    result = [[1, 0], [0, 1]]  
    base = matrix
    
    while n > 0:
        if n % 2 == 1:
            result = matrix_multiply(result, base, mod)
        base = matrix_multiply(base, base, mod)
        n //= 2
    
    return result

def fibonacci_mod_k(k, mod=10**10):
    if k == 0:
        return 0
    elif k == 1:
        return 1
    
    F = [[1, 1], [1, 0]]
    
    result = matrix_power(F, k - 1, mod)
    
    return result[0][0]

t = int(input())
for _ in range(t):
    n = int(input())
    _7n = pow(7, n, 16000000000)
    _77n = pow(7, _7n,40000000000)
    ans = f'0000000000{fibonacci_mod_k(pow(7,_77n,150000000000))}'[-10:]
    print(ans)

#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
constexpr int MAXN = 1e6 + 7;
constexpr int INF = 2e9;
constexpr ll INFF = 1e18;
constexpr ll MOD = 998244353;
#define mkp make_pair
#define F first
#define S second
#define pb emplace_back
#define sz(v) ((int)(v).size())
#define all(v) (v).begin(), (v).end()

int32_t main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  int t;
  cin >> t;
  while (t--) {
    int n, m;
    cin >> n >> m;
    vector<int> a(n + m + 2);
    for (int i = 1; i <= n; i++)
      a[i] = i;
    for (int i = n + 2; i <= n + m + 1; i++)
      a[i] = i - 1;

    vector<int> ans;
    for (int round = 1;; round++) {
      int cnt = 0;
      if (round & 1) {
        for (int i = n + m + 1; i >= 1; i--) {
          if (a[i] == 0 || a[i] >= n + 1 || i == n + m + 1)
            continue;
          if (a[i + 1] == 0) {
            if (i + 1 != m + 1 + a[i] && i + 2 <= n + m + 1 &&
                a[i + 2] == a[i] + 1 && a[i + 2] <= n)
              break;
            cnt++;
            ans.pb(a[i]);
            swap(a[i], a[i + 1]);
          } else if (i + 2 <= n + m + 1 && a[i + 2] == 0 && a[i + 1] >= n + 1) {
            cnt++;
            ans.pb(a[i]);
            swap(a[i], a[i + 2]);
          } else
            continue;
        }
      } else {
        for (int i = 1; i <= n + m + 1; i++) {
          if (a[i] == 0 || a[i] <= n || i == 1)
            continue;
          if (a[i - 1] == 0) {
            if (i - 1 != (a[i] - n) && i - 2 >= 1 && a[i - 2] == a[i] - 1 &&
                a[i - 2] >= n + 1)
              break;
            cnt++;
            ans.pb(a[i]);
            swap(a[i], a[i - 1]);
          } else if (i - 2 >= 1 && a[i - 2] == 0 && a[i - 1] <= n) {
            cnt++;
            ans.pb(a[i]);
            swap(a[i], a[i - 2]);
          } else
            continue;
        }
      }
      if (cnt == 0)
        break;
    }
    for (int i : ans)
      cout << i << ' ';
    cout << '\n';
  }
}

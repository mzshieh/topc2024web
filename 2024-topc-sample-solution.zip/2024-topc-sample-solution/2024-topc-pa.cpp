#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
constexpr int MAXN = 1e6 + 7;
constexpr int INF = 2e9;
constexpr ll INFF = 1e18;
constexpr ll MOD = 998244353;
#define mkp make_pair
#define F first
#define S second
#define pb emplace_back
#define sz(v) ((int)(v).size())
#define all(v) (v).begin(), (v).end()

int32_t main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  int n;
  cin >> n;
  vector<string> v(n);
  vector<int> power(n);
  int mx = 0;
  ll ans = 0;
  for (int i = 0; i < n; i++) {
    cin >> v[i] >> power[i];
    if (v[i] == "pig")
      mx = max(mx, power[i]);
  }
  ans += mx;
  for (int i = 0; i < n; i++) {
    if (v[i] != "pig" && power[i] < mx)
      ans += power[i];
  }
  cout << ans << '\n';
}

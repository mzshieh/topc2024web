n = int(input())
pig_power = 0
other = []
for _ in range(n):
    s, l = input().strip().split()
    l = int(l)
    if s == 'pig':
        pig_power = max(pig_power, l)
    else:
        other.append(l)
print(pig_power + sum(p for p in other if p < pig_power))

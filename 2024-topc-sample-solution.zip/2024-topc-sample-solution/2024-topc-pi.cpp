#include <iostream>
#include <vector>
using namespace std;

int main() {
  int n;
  cin >> n;
  vector<int> a(n - 1);
  for (auto &i : a)
    cin >> i;

  vector<vector<bool>> dp(1 << (n - 1), vector<bool>(101));
  vector<vector<int>> backtrace(1 << (n - 1), vector<int>(100));
  for (int i = 1; i <= 100; i++)
    dp[0][i] = 1;
  for (int i = 0; i < (1 << (n - 1)); i++) {
    for (int j = 0; j < (n - 1); j++) {
      if ((i >> j) & 1)
        continue;
      for (int k = 1; k <= 100; k++) {
        if (a[j] % k != 0 || a[j] / k > 100)
          continue;
        if (dp[i][k] == 0)
          continue;
        dp[i ^ (1 << j)][a[j] / k] = 1;
        backtrace[i ^ (1 << j)][a[j] / k] = j;
      }
    }
  }

  vector<int> ans(n);
  int cur_mask = (1 << (n - 1)) - 1, cur_num = 0;
  int idx = 0;
  for (int i = 1; i <= 100; i++)
    if (dp[cur_mask][i]) {
      cur_num = i;
      idx = backtrace[cur_mask][i];
      break;
    }
  if (cur_num == 0) {
    cout << "No\n";
  } else {
    cout << "Yes\n";
    ans[0] = cur_num;
    for (int i = 1; i <= n - 1; i++) {
      cur_num = a[idx] / cur_num;
      cur_mask ^= (1 << idx);
      idx = backtrace[cur_mask][cur_num];
      ans[i] = cur_num;
    }
    for (int i = 0; i < n; i++)
      cout << ans[i] << " \n"[i == n - 1];
  }
}

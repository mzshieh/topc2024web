#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
constexpr int MAXN = 1e6 + 7;
constexpr int INF = 2e9;
constexpr ll INFF = 1e18;
constexpr ll MOD = 998244353;
#define mkp make_pair
#define F first
#define S second
#define pb emplace_back
#define sz(v) ((int)(v).size())
#define all(v) (v).begin(), (v).end()

struct Line {
  mutable ll k, m, p;
  bool operator<(const Line &o) const { return k < o.k; }
  bool operator<(ll x) const { return p < x; }
};
// add: line y=kx+m, query: maximum y of given x
struct LineContainer : multiset<Line, less<>> {
  // (for doubles, use inf = 1/.0, div(a,b) = a/b)
  static const ll inf = LLONG_MAX;
  ll div(ll a, ll b) { // floored division
    return a / b - ((a ^ b) < 0 && a % b);
  }
  bool isect(iterator x, iterator y) {
    if (y == end())
      return x->p = inf, 0;
    if (x->k == y->k)
      x->p = x->m > y->m ? inf : -inf;
    else
      x->p = div(y->m - x->m, x->k - y->k);
    return x->p >= y->p;
  }
  void add(ll k, ll m) {
    auto z = insert({k, m, 0}), y = z++, x = y;
    while (isect(y, z))
      z = erase(z);
    if (x != begin() && isect(--x, y))
      isect(x, y = erase(y));
    while ((y = x) != begin() && (--x)->p >= y->p)
      isect(x, erase(y));
  }
  ll query(ll x) {
    assert(!empty());
    auto l = *lower_bound(x);
    return l.k * x + l.m;
  }
};

struct segtree {
  int n;
  vector<LineContainer> node;

  void init(int _n) {
    n = _n;
    node.resize(4 * n + 1);
    for (int i = 0; i <= 4 * n; i++)
      node[i].clear();
  }

  void add(int now, int l, int r, int x, ll k, ll m) {
    node[now].add(k, m);
    if (l == r)
      return;
    int mm = (l + r) >> 1;
    if (x <= mm)
      add(now << 1, l, mm, x, k, m);
    else
      add(now << 1 | 1, mm + 1, r, x, k, m);
  }

  int bin_search(int now, int l, int r, ll x, ll val) {
    if (l == r) {
      return l;
    }
    int m = (l + r) >> 1;
    if (sz(node[now << 1]) == 0)
      return bin_search(now << 1 | 1, m + 1, r, x, val);
    auto v = node[now << 1].query(x);
    if (v >= val)
      return bin_search(now << 1, l, m, x, val);
    else
      return bin_search(now << 1 | 1, m + 1, r, x, val);
  }
} tree;

template <typename T> struct P {
  T x, y;
  P(T x = 0, T y = 0) : x(x), y(y) {}
  bool operator<(const P &p) const { return tie(x, y) < tie(p.x, p.y); }
  bool operator==(const P &p) const { return tie(x, y) == tie(p.x, p.y); }
  P operator-() const { return {-x, -y}; }
  P operator+(P p) const { return {x + p.x, y + p.y}; }
  P operator-(P p) const { return {x - p.x, y - p.y}; }
  P operator*(T d) const { return {x * d, y * d}; }
  P operator/(T d) const { return {x / d, y / d}; }
  T dist2() const { return x * x + y * y; }
  double len() const { return sqrt(dist2()); }
  P unit() const { return *this / len(); }
  friend T dot(P a, P b) { return a.x * b.x + a.y * b.y; }
  friend T cross(P a, P b) { return a.x * b.y - a.y * b.x; }
  friend T cross(P a, P b, P o) { return cross(a - o, b - o); }
};
using pt = P<__int128>;

int32_t main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  int t;
  cin >> t;
  while (t--) {
    int n;
    cin >> n;
    vector<ll> a(n + 1);
    for (int i = 1; i <= n; i++) {
      cin >> a[i];
      a[i] += a[i - 1];
    }

    tree.init(n);
    vector<pt> p(n + 1), h(n + 1); // h(n+1) edge case
    vector<int> ans(n);
    p[0].x = p[0].y = 0;
    for (int i = 1; i <= n; i++) {
      p[i].x = i;
      p[i].y = a[i];
    }
    int t = 0;
    for (int i = n; i >= 0; i--) {
      while (t >= 2 && cross(p[i], h[t - 1], h[t - 2]) > 0)
        t--;

      auto calculate_round = [&](pt b, pt a) {
        auto int_part = (b.y - a.y) / (b.x - a.x);
        auto rem_part = (b.y - a.y) % (b.x - a.x);
        if (rem_part >= (b.x - a.x + 1) / 2)
          int_part++;
        return int_part;
      };

      if (i < n) {
        ll max_round = calculate_round(h[t - 1], p[i]);
        int r_level = tree.bin_search(1, 1, n, max_round * 2 - 1,
                                      2 * a[i] - i * (max_round * 2 - 1));
        ans[i] = r_level - i;
      }
      if (i)
        tree.add(1, 1, n, i, -i, 2 * a[i]);

      h[t] = p[i];
      t++;
    }

    for (int i : ans)
      cout << i << ' ';
    cout << '\n';
  }
}

#include <bits/stdc++.h>
using namespace std;

using ll = long long;

int main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  ll n, k;
  cin >> n >> k;
  auto n_nodes = n;
  vector<ll> nodes;
  for (ll i = 1;; i <<= 1) {
    if (n_nodes == 0)
      break;
    if (n_nodes < i) {
      nodes.emplace_back(n_nodes);
      break;
    }
    nodes.emplace_back(i);
    n_nodes -= i;
  }

  int m = nodes.size();
  ll ans = 0;
  for (int i = 0; i < m; i++) {
    if (i == m - 1) {
      if (k >= i + 1)
        ans += nodes[i];
      continue;
    }
    ll average = 0;
    for (int j = i + 1; j + 1 < m; j++)
      average += nodes[j] / nodes[i];
    ll v = nodes[m - 2] / nodes[i] * 2;
    ll cat1 = nodes[m - 1] / v;
    ll cat2 = (nodes[m - 1] % v > 0 ? 1 : 0);
    ll cat3 = nodes[i] - cat1 - cat2;
    if (k >= i + 1 && k <= n - average - v)
      ans += cat1;
    if (k >= i + 1 && k <= n - average - nodes[m - 1] % v)
      ans += cat2;
    if (k >= i + 1 && k <= n - average)
      ans += cat3;
  }
  cout << ans << '\n';
}
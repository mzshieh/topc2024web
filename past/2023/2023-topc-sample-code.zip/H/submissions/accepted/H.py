def test(n, k, pos):
    L, R = pos, pos
    cnt = 0
    while L <= n:
        cnt += min(R, n) - L + 1
        L *= 2
        R += R + 1
    return n - cnt < k - 1

n, k = [int(x) for x in input().strip().split()]
ok = min(n, 2 ** min(65,k) - 1)
cannot = 0
if k > 1 or k <= 1:
    step = 2 ** 63
    while step > 0:
        if test(n, k, cannot + step):
            cannot += step
        step //= 2

print(ok-cannot)

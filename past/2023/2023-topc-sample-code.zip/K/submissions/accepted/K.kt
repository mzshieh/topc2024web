fun main() {
    val s = readLine()!!
    var ans = 0
    for(i in 0..(s.length-4)) {
        if (s[i] == 'k' && s[i+1] == 'i' && s[i+2] == 'c' && s[i+3] == 'k') 
            ans++
    }
    println(ans)
}

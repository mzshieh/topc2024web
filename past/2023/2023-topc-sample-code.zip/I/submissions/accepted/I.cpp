#include <bits/stdc++.h>
using namespace std;


const int MOD = 1e9+7;
long long C[205][205] = {}, F[205]={}, TWO[205] = {};
void add(int &x, int v) {
  x += v;
  if (x >= MOD) x -= MOD;
  return;
}
long long EXTGCD(long long x, long long y) {
  long long p=1, q=0, r=0, s=1;
  while (y != 0) {
    long long w=x/y;
    x=x%y;
    p-=w*r;
    q-=w*s;
    swap(x, y);
    swap(p, r);
    swap(q, s);
  }
  return p;
}
long long INV(long long val) {
  return EXTGCD(val, MOD);
}

void solve() {
  int n;
  scanf("%d", &n);
  vector<int> a(2*n);
  vector<int> occur(n+1, 0);
  for(int i=0;i<2*n;i++) scanf("%d", &a[i]);
  for(int i=0;i<2*n;i++) occur[a[i]]++;
  int m1 = 0, m0 = 0;
  for(int i=1;i<=n;i++) {
    if(occur[i]==1) ++m1;
    if(occur[i]==0) ++m0;
  }
  int dp[3][105][105]={};
  dp[0][0][0] = 1;
  dp[1][0][0] = 1;
  int u=1,u1=0,u2=2;
  for (int l=1;l<2*n;l++) {
    swap(u1,u2);
    swap(u,u1);
    memcpy(dp[u], dp[u1], sizeof(dp[u]));
    
    if (a[l]==0 && a[l-1]==0) {
      for(int i=1;i<=m0;i++)
        for(int j=0;j<=m1;j++) {
          add(dp[u][i][j], dp[u2][i-1][j]);
        }
    } else if ((a[l] == 0 && occur[a[l-1]] == 1) ||
              (a[l-1]==0 && occur[a[l]] == 1)) {
      for(int i=0;i<=m0;i++)
        for(int j=1;j<=m1;j++) {
          add(dp[u][i][j], dp[u2][i][j-1]);
        }
    }
  }
  long long answer = 0;
  for(int i=0;i<=m0;i++)
    for(int j=0;j<=m1;j++) {
      long long tmp = C[m0][i] * F[i] % MOD * dp[u][i][j] % MOD * F[2*(m0-i) + (m1-j)] % MOD * TWO[m0-i] % MOD;
      
      // printf("i=%d, j=%d, tmp=%lld, dp=%d\n", i, j, tmp, dp[u][i][j]);
      if ((i+j)%2==0) {
        answer += tmp;
      } else {
        answer += (MOD - tmp);
      }
    }
  answer %= MOD;
  printf("%lld\n", answer);
  return;
}

int main() {
  int T;
  
  C[0][0] = 1;
  for (int i=1;i<=200;i++) {
    C[i][0] = 1;
    for(int j=1;j<=i;j++) {
      C[i][j] = (C[i-1][j] + C[i-1][j-1]) % MOD;
    }
  }
  F[0] = F[1] = 1;
  for(int i=2;i<=200;i++) F[i] = F[i-1] * (long long) i % MOD;
  TWO[0] = 1;
  for(int i=1;i<=200;i++) TWO[i] = TWO[i-1] * 2 % MOD;
  for(int i=1;i<=200;i++) TWO[i] = (INV(TWO[i]) % MOD + MOD)%MOD;

  scanf("%d", &T);
  while(T--) solve();
  return 0;
}

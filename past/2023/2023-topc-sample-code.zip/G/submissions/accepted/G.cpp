#include <algorithm>
#include <array>
#include <cassert>
#include <iostream>
#include <tuple>
#include <vector>

using namespace std;

using ll = long long;

constexpr ll MOD = 1'000'000'007;

struct Vec {
    ll x, y;
    Vec() : Vec(0, 0) {}
    Vec(ll x_, ll y_) : x(x_), y(y_) {}
    Vec operator-() const {
        return {-x, -y};
    }
    Vec operator+(const Vec &other) const {
        return {x + other.x, y + other.y};
    }
    Vec operator-(const Vec &other) const {
        return {x - other.x, y - other.y};
    }
    ll operator^(const Vec &other) const {
        return x * other.y - y * other.x;
    }
    [[nodiscard]] bool btm() const {
        return y < 0 || (y == 0 && x < 0);
    }
};

ll cross(Vec a, Vec b, Vec o) {
    return (a - o) ^ (b - o);
}

bool lexico_cmp(const Vec &a, const Vec &b) {
    if (a.x != b.x) {
        return a.x < b.x;
    }
    return a.y < b.y;
}

vector<vector<int>> num_above;
vector<ll> pow2;
vector<Vec> ps;

void prepare() {
    int n = ps.size();

    num_above.assign(n, vector(n, 0));
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            for (int k = i + 1; k < j; k++) {
                if (cross(ps[i], ps[j], ps[k]) > 0) {
                    num_above[i][j]++;
                }
            }
            num_above[j][i] = num_above[i][j];
        }
    }

    pow2.resize(n + 1);
    pow2[0] = 1;
    for (int i = 1; i <= n; i++) {
        pow2[i] = pow2[i - 1] * 2 % MOD;
    }
}

int num_between(int i, int j, int k) {
    if (i > j) {
        swap(i, j);
    }
    if (j > k) {
        swap(j, k);
    }
    if (i > j) {
        swap(i, j);
    }
    int cnt = num_above[i][j] + num_above[j][k] - num_above[i][k];
    return cnt >= 0 ? cnt : -cnt - 1;
}

int main() {
    int n;
    cin >> n;
    assert(4 <= n && n <= 500);
    vector<pair<Vec, char>> points(n);
    for (auto &[p, c] : points) {
        cin >> p.x >> p.y >> c;
    }
    sort(points.begin(), points.end(),
         [](auto &a, auto &b) { return lexico_cmp(a.first, b.first); });

    ps.resize(n);
    vector<char> color(n);
    for (int i = 0; i < n; i++) {
        ps[i] = points[i].first;
        color[i] = points[i].second;
    }

    vector<tuple<Vec, int, int>> slopes;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (color[i] != color[j] && !(ps[i] - ps[j]).btm()) {
                slopes.emplace_back(ps[j] - ps[i], i, j);
            }
        }
    }
    sort(slopes.begin(), slopes.end(), [](const auto &a, const auto &b) {
        return (get<0>(a) ^ get<0>(b)) > 0;
    });

    prepare();

    vector dp(n, vector<ll>(n)), dp2 = dp;
    for (int i = 0; i < n; i++) {
        dp[i][i] = 1;
        dp2[i][i] = 1;
    }

    for (const auto &[s, i, j] : slopes) {
        for (int k = 0; k < n; k++) {
            dp[i][k] = (dp[i][k] + dp[j][k] * pow2[num_between(i, j, k)]) % MOD;
        }
    }

    for (const auto &[s, i, j] : slopes) {
        for (int k = 0; k < n; k++) {
            dp2[j][k] =
                (dp2[j][k] + dp2[i][k] * pow2[num_between(i, j, k)]) % MOD;
        }
    }

    ll ans = MOD - n - (ll)slopes.size();
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            ans = (ans + dp[i][j] * dp2[j][i]) % MOD;
        }
    }
    cout << ans << '\n';
}

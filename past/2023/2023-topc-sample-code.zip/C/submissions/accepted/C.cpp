#include <bits/stdc++.h>
using namespace std;

constexpr int INF = 1'000'000'000;

int main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  string s;
  unsigned long long b;
  cin >> s >> b;

  int n = s.length();
  vector<vector<int>> dp(n, vector<int>(20, INF));
  vector<vector<__int128_t>> numbers(n);
  for (int i = n - 1; i >= 0; i--) {
    __int128_t num = 0;
    for (int j = i; j < n && j - i + 1 <= 20; j++) {
      num = num * 10 + (s[j] - '0');
      if (s[i] == '0' && j > i) // leading 0
        continue;
      numbers[i].emplace_back(num);
      if (j == n - 1) {
        if (num <= b)
          dp[i][j - i] = 0;
      } else {
        for (int k = 0; k < numbers[j + 1].size(); k++)
          if (num <= numbers[j + 1][k])
            dp[i][j - i] = min(dp[i][j - i], dp[j + 1][k] + 1);
      }
    }
  }
  int ans = *min_element(dp[0].begin(), dp[0].end());
  if (ans == INF)
    cout << "NO WAY\n";
  else
    cout << ans << '\n';
}
#include<cstdio>
#include<cstring>
#include<algorithm>

using namespace std;

int main() {
    static char b[32], s[100001];
    static int dp[100000][20];
    scanf("%s %s", &s, &b);
    int n = strlen(s), m = strlen(b);
    for (int i = 0; i < n; i++) 
        for(int j = 0; j <= m; j++)
            dp[i][j] = 1e7;
    for (int i = 1; b[i-1]; i++) 
        dp[n-i][i] = (s[n-i] != '0') ? 0 : 1e7;
    if (strncmp(s+n-m, b, m) > 0) 
        dp[n-m][m] = 1e7;
    if (strcmp("0", s) == 0) dp[0][1] = 0;
    for (int i = n-2; i >= 0; i--) {
        if (s[i] == '0') continue;
        for (int j = 1; j < m && i + j + j <= n; j++) {
            if (strncmp(s+i, s+i+j, j) <= 0) dp[i][j] = min(dp[i][j], dp[i+j][j] + 1);
            for (int k = j+1; k < m && i + j + k <= n; k++) {
                dp[i][j] = min(dp[i][j], dp[i+j][k] + 1);
            }
            if (i + j + m <= n && strncmp(s+i+j, b, m) <= 0) dp[i][j] = min(dp[i][j], dp[i+j][m] + 1);
        } 
        if (i + m + m > n)  continue;
        if (strncmp(s+i+m, b, m) > 0 ||strncmp(s+i, s+i+m, m) > 0) continue;
        dp[i][m] = min(dp[i][m], dp[i+m][m] + 1);
    }
    int ans = 1e7;
    for (int i = 1; i <= m; i++) 
        ans = min(ans, dp[0][i]);
    if (ans < 1e7)
        printf("%d\n", ans);
    else 
        puts("NO WAY");;
    return 0;
}

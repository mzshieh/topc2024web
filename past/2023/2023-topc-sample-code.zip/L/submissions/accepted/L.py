n = int(input().strip())
x = []
y = []
for i in range(n):
    p, q = [int(v) for v in input().strip().split()]
    x.append(p)
    y.append(q)
x.sort()
y.sort()
if n % 2 == 0:
    print(x[n//2-1],y[n//2-1])
else:
    print(x[n//2],y[n//2])

if input() <= '2023-09-16':
    print('GOOD')
else:
    print('TOO LATE')

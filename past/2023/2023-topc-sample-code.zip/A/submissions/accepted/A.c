#include<stdio.h>

int main() {
    char date[64];
    char *deadline = "2023-09-16";
    scanf("%s", date);
    for (char *p = date; *p; p++) {
        if (*deadline < *p) {
            puts("TOO LATE");
            return 0;
        }
        if (*(deadline++) > *p) {
            puts("GOOD");
            return 0;
        }
    }
    puts("GOOD");
    return 0;
}

import java.io.*;
import java.util.*;

public class A{
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        String date = sc.next();
        if (date.compareTo("2023-09-16") <= 0) {
            System.out.println("GOOD");
        } else {
            System.out.println("TOO LATE");
        }
    }
}

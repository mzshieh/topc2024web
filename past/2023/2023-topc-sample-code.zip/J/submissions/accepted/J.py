print(4000*int(input()))

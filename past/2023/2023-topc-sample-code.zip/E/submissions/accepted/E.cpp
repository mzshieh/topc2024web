#include <bits/stdc++.h>
using namespace std;

using ull = unsigned long long;
using ulll = __uint128_t;
ull a, b, m;

struct matrix {
  ull A[2][2];
  matrix() { memset(A, 0, sizeof A); }
  matrix operator*(const matrix &rhs) const {
    matrix ret;
    for (int i = 0; i < 2; i++)
      for (int j = 0; j < 2; j++)
        for (int k = 0; k < 2; k++) {
          ret.A[i][j] =
              ((ulll)ret.A[i][j] + (ulll)A[i][k] * rhs.A[k][j] % m) % m;
        }
    return ret;
  }
};

int main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  cin >> a >> b >> m;

  matrix M, ans;
  M.A[0][0] = a, M.A[0][1] = m - 1;
  M.A[1][0] = 1, M.A[1][1] = 0;
  ans.A[0][0] = 1, ans.A[0][1] = 0;
  ans.A[1][0] = 0, ans.A[1][1] = 1;
  b--;
  while (b) {
    if (b & 1)
      ans = ans * M;
    M = M * M;
    b >>= 1;
  }
  cout << (ull)(((ulll)ans.A[0][0] * a % m + (ulll)ans.A[0][1] * 2 % m) % m)
       << '\n';
}
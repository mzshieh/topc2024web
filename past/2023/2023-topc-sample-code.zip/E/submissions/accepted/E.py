a, b, m = [int(x) for x in input().strip().split()]

lookup = {}

def sol(a, b, m):
    if (ret := lookup.get(b)) != None: return lookup[b]
    if b == 0: ret = 2 % m
    elif b == 1: ret = a % m
    elif b % 2 == 0: ret = (sol(a, b//2, m) ** 2 - 2) % m
    else: ret = (sol(a, b//2, m) * sol(a, b-b//2, m) - a) % m
    lookup[b] = ret
    return ret

print(sol(a, b, m))

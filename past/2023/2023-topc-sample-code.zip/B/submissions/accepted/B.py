rt, rj, st, sj = [x for x in input().strip().split()]
rt = int(rt)
rj = int(rj)
st = int(float(st)*100 + 0.5)
sj = int(float(sj)*100 + 0.5)
if (rt-1)*sj < (rj-1)*st:
    print('TAOYUAN')
elif (rt-1)*sj > (rj-1)*st:
    print('JAKARTA')
else:
    print('SAME')

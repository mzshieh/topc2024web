#include <bits/stdc++.h>
using namespace std;

constexpr int MAXN = 2000005;
vector<int> G[MAXN];
int p[MAXN], depth[MAXN];

void dfs(int now, int par) {
  p[now] = par;
  for (int i : G[now]) {
    if (i == par)
      continue;
    depth[i] = depth[now] + 1;
    dfs(i, now);
  }
}

struct DSU {
  vector<int> p;

  void init(int n) {
    p.resize(n + 1);
    for (int i = 1; i <= n; i++)
      p[i] = i;
  }

  int Find(int x) { return p[x] == x ? x : p[x] = Find(p[x]); }

  void Union(int x, int y) {
    x = Find(x), y = Find(y);
    if (x == y)
      return;
    else if (depth[x] < depth[y]) {
      p[y] = x;
    } else {
      p[x] = y;
    }
  }
} dsu;

int main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  int n, m, q;
  cin >> n >> m >> q;
  vector<pair<int, int>> edges(m);
  vector<unordered_map<int, int>> edge_tag(n + 1);
  for (auto &[u, v] : edges) {
    cin >> u >> v;
    if (u > v)
      swap(u, v);
    edge_tag[u][v] = 0;
  }
  int cur_tag = m;
  for (int i = 1; i <= q; i++) {
    int u, v;
    cin >> u >> v;
    if (u > v)
      swap(u, v);
    edge_tag[u][v] = cur_tag--;
  }
  for (auto &m : edge_tag)
    for (auto &[v, idx] : m) {
    if (idx == 0)
      idx = cur_tag--;
  }

  sort(edges.begin(), edges.end(), [&](pair<int, int> e1, pair<int, int> e2) {
    return edge_tag[e1.first][e1.second] < edge_tag[e2.first][e2.second];
  });
  dsu.init(n);
  map<pair<int, int>, int> is_tree_edge;
  for (auto [u, v] : edges) {
    if (dsu.Find(u) != dsu.Find(v)) {
      dsu.Union(u, v);
      is_tree_edge[{u, v}] = 1;
      G[u].emplace_back(v);
      G[v].emplace_back(u);
    }
  }
  for (int i = 1; i <= n; i++) {
    if (dsu.Find(i) == i) {
      depth[i] = 0;
      dfs(i, -1);
    }
  }

  dsu.init(n);
  int cur_ans = 0;
  vector<int> ans = {0};
  for (auto [u, v] : edges) {
    if (is_tree_edge[{u, v}])
      cur_ans++;
    else {
      u = dsu.Find(u), v = dsu.Find(v);
      while (u != v) {
        if (depth[u] > depth[v]) {
          dsu.Union(u, p[u]);
          u = dsu.Find(p[u]);
        } else {
          dsu.Union(v, p[v]);
          v = dsu.Find(p[v]);
        }
        cur_ans--;
      }
    }
    ans.emplace_back(cur_ans);
  }
  reverse(ans.begin(), ans.end());
  for (int i = 1; i <= q; i++)
    cout << ans[i] << '\n';
}
